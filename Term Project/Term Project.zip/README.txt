Updates since demo
------------------
- Added Welch as 2nd Windowing function.
- Improved speed of loading in a file.
- Added Filtering option to apply low pass filter.
- Inverse DFT can now be shown.
- Save function now works
- Cut Copy Paste is now able to be tested with save function.

How to use the program
-----------------------
File --> New
File --> Open

To Apply Filter
----------------
Select a portion of the frequency graph.
Apply DFT to it.
Select a portion on the amplitude graph then click filter.

Apply Windowing function
-------------------------
Select a portion of the frequency graph.
Click on window at the top and select which windowing function to apply.
**Windowing may take a long time **

Recorder can record and play back the same audio.
-Unable to display recorded data.